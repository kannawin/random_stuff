#!/usr/bin/python3

import time
import sys
import logging
import configparser
import json
import stomp
import os


host = os.getenv("HOST")
port = os.getenv("PORT")

class MyListener(stomp.ConnectionListener):
    def on_error(self, headers, message):
      print('receieved an error "%s"' % message)
    def on_message(self, headers, message):
      print('receieved a message "%s"' % message)    

def send_message(queue_name, message):
    if host is not None:
        conn = stomp.Connection([('%s' % str(host), int(port))])
    else:
        conn = stomp.Connection10()
    conn.set_listener('/queue/events', MyListener())
    conn.start()
    conn.connect()

    #try to send JSON version first, if not able to, send as string
    try:
        conn.send(queue_name, json.dumps(message))
    except ValueError as e:
        conn.send(queue_name, "%s".format(message))

def send_message_to_default_queue(message):
    SendMessage('/queue/events', message)

