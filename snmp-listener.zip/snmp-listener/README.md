# snmp-listener
Event and Alert listener via SNMP

## Pre reqs
Install docker-compose on your dev machine

## Dev
'''bash
docker-compose up
'''
will spin up the local Postgres DB (port 5432)

## Build image from source code
'''bashdocker build . --tag snmp-listener:<version>
'''
will locally build the image
