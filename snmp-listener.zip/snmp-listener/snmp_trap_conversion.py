#!/usr/bin/python3
"""
*   Copyright (c) 2020 Dell Inc. All rights reserved.                    *
*                                                                        *
* DELL INC. CONFIDENTIAL AND PROPRIETARY INFORMATION. This software may  *
* only be supplied under the terms of a license agreement or             *
* nondisclosure agreement with Dell Inc. and may not be copied or        *
* disclosed except in accordance with the terms of such agreement.       *
"""
import datetime
import logging
import json
import os
from os import listdir
import psycopg2
import elasticsearch
from db.credential_manager import CredentialManager
from db.facts.facts import get_facts_by_ip
import db.event_conversion
import message_queue
import configparser

from pysmi.reader import FileReader
from pysmi.searcher import PyFileSearcher, PyPackageSearcher, StubSearcher
from pysmi.writer import PyFileWriter
from pysmi.parser import SmiStarParser
from pysmi.codegen import PySnmpCodeGen
from pysnmp.carrier.asyncore.dgram import udp
from pysnmp.carrier.error import CarrierError
from pysnmp.entity import engine, config
from pysnmp.entity.rfc3413 import ntforg, ntfrcv
from pysnmp.entity.rfc3413.oneliner import cmdgen
from pysnmp.hlapi import OctetString
from pysnmp.proto.api import v2c
from pysnmp.smi import builder, view, compiler
from pysnmp.smi.error import MibNotFoundError
from pysnmp.smi.rfc1902 import ObjectIdentity, ObjectType


SERVER_ADDRESS = os.getenv("HOST")
SNMP_PORT = os.getenv("SNMP_PORT")
MIB_SOURCE_DIRECTORIES = "snmp-mibs"
MIB_DEST_DIRECTORY = "snmp-mibs"
TRAP_PROPERTIES_FILE_PATH = "files/Snmp-Trap-Properties.json"
UNKNOWN_TRAP_MESSAGE_ID = "MISC9000"
SUPPORTED_DEVICE_TYPES = {"RackServer", "dellswitch", "dellswitchos10", "clc", "vxflexmanager"}

DB_USERNAME = os.getenv("DB_USER")

# pylint: disable= multiple-statements, line-too-long , logging-not-lazy, logging-format-interpolation

def get_local_engine_id():
    """
    Gets the engine ID of the system using pysnmp
    """
    try:
        cmd_gen = cmdgen.CommandGenerator()
        _, error_status, _, var_binds = cmd_gen.getCmd(cmdgen.CommunityData('public'),
                                                       cmdgen.UdpTransportTarget(('localhost', 161)),
                                                       '1.3.6.1.6.3.10.2.1.1.0',
                                                       lookupNames=True, lookupValues=True)
        if error_status == 0:
            _, value = var_binds[0]
            engine_id = value.prettyPrint()
            if engine_id.startswith('0x'):
                return engine_id
        logging.debug("Failed to retrieve the engine id")
    # Since we don't know what exceptions are coming back at this time
    except Exception as exception:  # pylint: disable=broad-except
        logging.debug("Failed to retrieve the engine id: %s" % exception)  # pylint: disable=logging-not-lazy

    return None


def fetch_device_ip_and_type_from_database():
    '''
    This function connects and fetches a dictionary of ip_address and the device type from
    device_inventory table in asm_manager db
    '''
    connection = None  # Signifies no established connection
    try:
        connection = psycopg2.connect("dbname={} user={}".format('asm_manager', DB_USERNAME))
        cursor = connection.cursor()
        postgres_query = "SELECT ip_address,device_type FROM device_inventory"
        cursor.execute(postgres_query)
        device_records = cursor.fetchall()

    except (Exception, psycopg2.DatabaseError) as db_error:  # pylint: disable=broad-except
        error_msg = "Failed to fetch records from the database {}".format(db_error)
        logging.error(error_msg)
        return {}

    finally:
        if connection is not None:
            cursor.close()
            connection.close()
            logging.info('Connection to asm_manager DB is closed.')
            
    device_ip_type_map = dict(device_records)
    device_ip_type_map['127.0.0.1'] = 'vxflexmanager'  # Add VxFlex Manager as a device with the local address
    return device_ip_type_map


def get_mib_names_from_file_path():
    """
    Gets the list of MIB file names from the MIB_SOURCE_DIRECTORY

    Args:
        None

    Returns:
        mib_list: A list with all the MIB file names
    """
    mib_list = []
    for file_name_with_ext in listdir(MIB_SOURCE_DIRECTORIES[0]):
        file_name = file_name_with_ext.split('.')[0]
        mib_list.append(file_name)
    return mib_list


def compile_and_load_mibs():
    """
    Compiles the MIB files in the specified source directory and populates the destination directory
    with compiled MIBs. Then loads the specified MIBs from the destination directory

    Args:
        None

    Returns:
        boolean: Status of the outcome
        mib_view: A MibView object
        error: A string representing the error
    """
    try:
        mib_builder = builder.MibBuilder()
        mib_compiler = compiler.MibCompiler(SmiStarParser(), PySnmpCodeGen(), PyFileWriter(MIB_DEST_DIRECTORY))
        mib_compiler.addSources(*[FileReader(x) for x in MIB_SOURCE_DIRECTORIES])
        mib_compiler.addSearchers(PyFileSearcher(MIB_DEST_DIRECTORY))
        mib_compiler.addSearchers(*[PyPackageSearcher(x) for x in PySnmpCodeGen.defaultMibPackages])
        mib_compiler.addSearchers(StubSearcher(*PySnmpCodeGen.baseMibs))
        mib_list = get_mib_names_from_file_path()
        mib_compiler.compile(*mib_list)
        mib_builder.addMibSources(builder.DirMibSource(MIB_DEST_DIRECTORY))
        mib_builder.loadModules(*mib_list)
        return True, view.MibViewController(mib_builder)
    except MibNotFoundError as mib_error:
        error_msg = "SNMP MIBs are not present to be loaded with exception: %s" % (str(mib_error))
        logging.error(error_msg)
        return False, error_msg


def load_json_with_trap_properties():
    """
    Loads the .json file from the specified source directory and converts a list of dictionaries into
    a single map with AlertMessageId as the key so that it will be easy for search

    Args:
        None

    Returns:
        boolean: Status of the outcome
        snmp_trap_properties: A dictionary with trap properties
        error: A string representing the error
    """
    try:
        with open(TRAP_PROPERTIES_FILE_PATH, 'r') as file_ptr:
            json_list = json.load(file_ptr)
        snmp_trap_properties = {d.pop("AlertMessageId"): d for d in map(dict, json_list)}
        snmp_trap_properties[UNKNOWN_TRAP_MESSAGE_ID] = {"CategoryName" : "Miscellaneous", "RecommendedAction": "Instrumentation didn't provide any recommended action for this event.", "SeverityName": "Unknown"}
        return True, snmp_trap_properties
    except ValueError as val_error:
        error_msg = "Error in reading the snmp_trap_properties from the %s file with exception: %s" % (TRAP_PROPERTIES_FILE_PATH, str(val_error))
        logging.error(error_msg)
    except KeyError as key_err:
        error_msg = "Key not found with exception: %s" % (str(key_err))
        logging.error(error_msg)
    return False, error_msg


def get_message_id_from_var_binds(trap_dict):
    """
    Returns the message id from a dictionary with the key that contains "alertmessageid"

    Args:
        None

    Returns:
        value: A string representing the message id
    """
    for key, value in trap_dict.iteritems():
        if key.lower().find('alertmessageid') != -1 or key.find('DELLEMC-OS10-SMI-MIB::dell') != -1:
            return value
    return UNKNOWN_TRAP_MESSAGE_ID


def prepare_payload(var_binds, source_ip_address, device_type, snmp_trap_properties):
    """
    Prepares the payload as key value pair

    Args:
        var_binds: Tuples of variable bindings of a trap
        source_ip_address: A string which represents the source ip address
        device_type: A string representing the type of the device
        snmp_properties: A dictionary with rackserver alert dump

    Returns:
        msg_body: A dictionary with all the necessary parsed fields of the trap
    """
    trap_dict = {name.prettyPrint(): None if val.prettyPrint() == "" else val.prettyPrint() for name, val in var_binds}

    # For iDRACs as to display in the UI and for traps from the local machine
    if device_type == "RackServer" or device_type == "vxflexmanager":
        message_id = get_message_id_from_var_binds(trap_dict)
        if message_id not in snmp_trap_properties or message_id == UNKNOWN_TRAP_MESSAGE_ID:
            message_id = UNKNOWN_TRAP_MESSAGE_ID
            trap_dict["DetailedDescription"] = json.dumps(trap_dict)
        trap_dict.update(snmp_trap_properties[message_id])

    trap_dict["TimeStamp"] = datetime.datetime.utcnow()
    trap_dict["SourceIpAddress"] = source_ip_address

    # populate the SeverityName field according to the device type
    if device_type == "RackServer":
        for k in trap_dict:
            if k.find("alertCurrentStatus") >= 0:
                trap_dict["SeverityName"] = trap_dict[k]
                break
    elif device_type == "clc":
        for k in trap_dict:
            if k.find("clAlarmSeverity") >= 0:
                if trap_dict[k] == "HIGH":
                    trap_dict["SeverityName"] = "critical"
                else:
                    trap_dict["SeverityName"] = trap_dict[k]
                break
    elif device_type == "dellswitchos10" or device_type == "dellswitch":
        for k in trap_dict:
            if k.find("snmpTrapOID.0") >= 0:
                if trap_dict[k].find("Major"):
                    trap_dict["SeverityName"] = "critical"
                    break
    #     trap_dict["SeverityName"] = "critical"
    # vxfm already sending the SeverityName with Warning, Info and Critical

    if "SeverityName" not in trap_dict:
        trap_dict["SeverityName"] = "Unknown"

    msg_body = {"srs_sent" : "0", "device_type" : device_type, "trap" : trap_dict}
    logging.debug(msg_body)
    return msg_body


def snmp_trap_version_and_authorization_conversion(engine_id, v2_users, v3_users, trap_forwardings):
    """Converts the v2c traps to v2c(different community strings) and v3 traps

    This method listens for the v2c traps with the specified community strings continuously
    and converts it to v2 traps with different community strings and v3 traps with any of the three security levels(minimal, moderate and maximum)
    and relays to a SNMPv2/SNMPv3 agent

    Args:
        engine_id: An octet string used for trap authentication
        v2_users: A list of v1/v2c community strings
        v3_users: A list of v3 users to which the traps are converted
        trap_forwardings: A list of target trap forwardings to which the traps are sent

    Returns:
        None
    """

    def cbFun(snmp_engine, state_reference, context_engine_id, context_name, var_binds, cb_ctx):  # pylint: disable=too-many-arguments, unused-argument
        """
        Callback function for receiving notifications
        """
        trap_pdu = v2c.TrapPDU()
        v2c.apiTrapPDU.setDefaults(trap_pdu)
        v2c.apiTrapPDU.setVarBinds(trap_pdu, var_binds)
        source_ip_address = snmp_engine.observer.getExecutionContext('rfc3412.receiveMessage:request')['transportAddress'][0]
        logging.info("Received the traps from %s" %source_ip_address)
        device_ip_type_map = fetch_device_ip_and_type_from_database()
        device_type = device_ip_type_map[source_ip_address] if source_ip_address in device_ip_type_map else "Unknown"
        if device_type in SUPPORTED_DEVICE_TYPES:
            var_binds = [ObjectType(ObjectIdentity(x[0]), x[1]).resolveWithMib(mib_view) for x in var_binds]  # Resolve the OID of the var_binds with actual string
        msg_body = prepare_payload(var_binds, source_ip_address, device_type, snmp_trap_properties)
		## convert to event status and push to message queue
        if not status:
            logging.error(msg)

        ntf_org = ntforg.NotificationOriginator()
        for distant_agent in distant_agents:
            ntf_org.sendPdu(snmp_engine, distant_agent, None, '', trap_pdu)
		#send to Message Queue	
        message_queue.send_message_to_default_queue(event_conversion.translate_event(msg))

    # Create SNMP engine with engineID and pre-bound to socket transport dispatcher
    try:
        if v3_users and engine_id:
            snmp_engine = engine.SnmpEngine(snmpEngineID=OctetString(hexValue=engine_id[2:]))
        else:
            snmp_engine = engine.SnmpEngine()
    except ValueError:
        return False, "Unable to retrieve the Engine ID"


    status, mib_view = compile_and_load_mibs()
    if not status:
        return status, mib_view

    status, snmp_trap_properties = load_json_with_trap_properties()
    if not status:
        return status, snmp_trap_properties
    # Transport setup
    # Agent section
    # UDP over IPv4
    try:
        config.addTransport(
            snmp_engine,
            udp.domainName + (1,),
            udp.UdpTransport().openServerMode((SERVER_ADDRESS, SNMP_PORT))
        )
    except CarrierError:
        error_msg = "Binding failed: Port %s is already in use" % SNMP_PORT
        logging.error(error_msg)
        return False, error_msg

    # Manager section
    # UDP over IPv4
    config.addTransport(
        snmp_engine,
        udp.domainName + (2,),
        udp.UdpTransport().openClientMode()
    )

    # SNMPv1/2c setup (Agent role)
    for v2_user in v2_users:
        config.addV1System(snmp_engine,
            v2_user['name'], 
            v2_user['name'])

    # below for loop iterates over all the discovered iDRAC(s) and gets the EngineID(s) from facts database
    # then SNMPv3 user(s) is/are added with retrieved EngineID and SNMPv3 creds (SNMPv3 userid, SNMPv3 Authentication Type as MD5, SNMPv3 Privacy Type as DES)
    # Note: Key lenghts for Authentication Type, Privacy Type should be minimum 8 characters (SNMP authentication and encryption keys must be at least 8 and at most 32 octets long)

    credential_mgr = CredentialManager()
    idrac_creds = credential_mgr.get_idrac_credentials()

    for credential in idrac_creds:
        try:
            engine_id = get_facts_by_ip(credential.ip)["facts"]["EngineID"]
            if engine_id: # check if engine id exists
                # below three configurations i.e noAuthNoPriv, AuthNoPriv, AuthPriv allows VxFM to listen
                # SNMPv3 traps for configured iDRAC(s) with all security levels(Minimum/Moderate/Maximum)
                # for iDRAC we are using MD5 and DES for Moderate Security (authNoPriv) and  Maximum Security (authPriv)

                if int(credential.snmpv3_security_level) == 1: #noAuthNoPriv (Minimum Security)
                    config.addV3User(snmp_engine, credential.snmpv3_userid, securityEngineId=OctetString(hexValue=engine_id[2:]))
                    logging.info("added SNMPv3 user for iDRAC: {} with Minimum Security (noAuthNoPriv)".format(credential.ip))
                elif int(credential.snmpv3_security_level) == 2: #authNoPriv (Moderate Security)
                    config.addV3User(snmp_engine, credential.snmpv3_userid, config.usmHMACMD5AuthProtocol, credential.snmpv3_authentication_passphrase, securityEngineId=OctetString(hexValue=engine_id[2:]))
                    logging.info("added SNMPv3 user for iDRAC: {} with Moderate Security (authNoPriv)".format(credential.ip))
                elif int(credential.snmpv3_security_level) == 3: #authPriv (Maximum Security)
                    #iDRAC(s) use the same passphrase for authentication and privacy : hence MD5 and DES are used with same credentials i.e. snmpv3_authentication_passphrase
                    config.addV3User(snmp_engine, credential.snmpv3_userid, config.usmHMACMD5AuthProtocol, credential.snmpv3_authentication_passphrase, config.usmDESPrivProtocol, credential.snmpv3_authentication_passphrase, securityEngineId=OctetString(hexValue=engine_id[2:]))
                    logging.info("added SNMPv3 user for iDRAC: {} with Maximum Security (authPriv)".format(credential.ip))
            else:
                logging.info("Engine ID not available : unable to add SNMPv3 user for iDRAC: {}".format(credential.ip))
        except Exception as exception:  # pylint: disable=broad-except as we do not know the exact pysnmp exception that will occur
            logging.debug("Failed to add SNMPv3 user for iDRAC %s : %s" % (credential.ip, exception))
            continue  #continue to next iteration

    # SNMPv2/SNMPv3/USM setup (Manager role)
    distant_agents = []
    for i, target in enumerate(trap_forwardings):
        distant_agent_auth = 'distant-agent-auth' + str(i)
        distant_agent = 'distant-agent' + str(i)
        distant_agents.append(distant_agent)
        if target['version'] == 'v2':
            config.addTargetParams(snmp_engine, distant_agent_auth, target['communityString'], 'noAuthNoPriv', 1)
        else:
            v3_user = next((v3_user for v3_user in v3_users if v3_user['username'] == target['user']), None)
            if v3_user['securityLevel'] == "1":
                config.addV3User(snmp_engine, v3_user['username'])
                config.addTargetParams(snmp_engine, distant_agent_auth,
                                       v3_user['username'], 'noAuthNoPriv')
            elif v3_user['securityLevel'] == "2":
                config.addV3User(snmp_engine, v3_user['username'],
                                 config.usmHMACMD5AuthProtocol, v3_user['md5Password'])
                config.addTargetParams(snmp_engine, distant_agent_auth,
                                       v3_user['username'], 'authNoPriv')
            elif v3_user['securityLevel'] == "3":
                config.addV3User(snmp_engine, v3_user['username'], config.usmHMACMD5AuthProtocol,
                                 v3_user['md5Password'], config.usmDESPrivProtocol,
                                 v3_user['desPrivacyPassword'])
                config.addTargetParams(snmp_engine, distant_agent_auth, v3_user['username'],
                                       'authPriv')

        config.addTargetAddr(
            snmp_engine, distant_agent, udp.domainName + (2,),
            (target['ipAddress'], int(target['port'])), distant_agent_auth, retryCount=0
        )

    ntfrcv.NotificationReceiver(snmp_engine, cbFun) # Register SNMP Application at the SNMP engine
    snmp_engine.transportDispatcher.jobStarted(1)  # this job would never finish
    # Run I/O dispatcher which would receive queries and send responses
    try:
        snmp_engine.transportDispatcher.runDispatcher()
    except:
        snmp_engine.transportDispatcher.closeDispatcher()
        raise
    finally:
        snmp_engine.transportDispatcher.closeDispatcher()
        snmp_engine.transportDispatcher.jobFinished(1)
