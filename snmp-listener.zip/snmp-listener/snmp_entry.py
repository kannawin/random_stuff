#!/bin/python3

import snmp_trap_conversion

##basic config until intergrated with UI

snmpv2 = [{"name":"public"}]
trap_forwardings = [{"communityString": "public",
					"version": "v2",
					"ipAddress": "127.0.0.1",
					"port": "162"}]
snmpv3 = []

snmp_trap_conversion.snmp_trap_version_and_authorization_conversion(0x800002a200000000000000, snmpv2, snmpv3, trap_forwardings)
