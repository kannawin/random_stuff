#!/bin/python3

import base64
import logging
import psycopg2
from Cryptodome import Random
from Cryptodome.Cipher import AES


class AESEncryptionMethod(object):
    """
    class used to decrypt and encrypt the password
    """

    def __init__(self, key):
        self.key = base64.b64decode(str(key))

    def encrypt(self, raw):
        """
        encrypt passed in raw data using AES encryption
        """
        raw = self._pad(raw)
        nonce = Random.new().read(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, nonce)
        return base64.b64encode(nonce + cipher.encrypt(raw))

    def decrypt(self, enc):
        """
        decrypt passed in enc data using AES encryption
        """
        enc = base64.b64decode(enc)
        nonce = enc[:AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, nonce)
        return self._unpad(cipher.decrypt(enc[AES.block_size:])).decode('utf-8')

    @staticmethod
    def _pad(crypt_data):
        """
        for AES encryption the data must be block size multiples
        so, if it is not we pad it before encryption
        """
        return crypt_data + (AES.block_size - len(crypt_data) % AES.block_size) * chr(AES.block_size - len(crypt_data) % AES.block_size)

    @staticmethod
    def _unpad(crypt_data):
        return crypt_data[:-ord(crypt_data[len(crypt_data) - 1:])]

class Credential(object):
    """
    store a single credential data to return from get calls
    """
    def __init__(self, userid, password, ip_address, cred_id, credential_manager):
        # store the values into the object
        self.ip = ip_address  #pylint: disable=invalid-name
        self.userid = userid
        self.password = password
        self.cred_id = cred_id
        self.snmpv3_userid, self.snmpv3_security_level, self.snmpv3_authentication_passphrase, self.snmpv3_privacy_passphrase = None, None, None, None

        self.community_string = credential_manager.get_snmp_v2_trap_credential(cred_id)
        if not self.community_string:
            self.community_string = 'public'
            self.snmpv3_userid, self.snmpv3_security_level, self.snmpv3_authentication_passphrase, self.snmpv3_privacy_passphrase = credential_manager.get_snmp_v3_user_credentials_for_listening(cred_id)

    def is_snmpv3(self):
        #check if SNMPv3 listening is present
        if self.snmpv3_userid:
            return True
        return False

class CredentialManager(object):
    """
    Class to collect usernames and passwords, as well as decrypt the passwords
    """
	
    def __init__(self, service_id=None):
        """
        Initial set up for CredentialMgr that includes a key and connection to database
        """

        # Establishes a connection to the encryptionmgr datbase
        try:
            _connection = psycopg2.connect("dbname=encryptionmgr user=orion")
            _cursor = _connection.cursor()
        except psycopg2.OperationalError as e:
            logging.error("failed to make psycopg2 connection to encryptionmgr. {0}".format(str(e.args[0])).encode("utf-8"))
            raise
        # Gets the encryption key necessary for decryption
        _cursor.execute("SELECT bytes FROM encryptionkey")
        self._key = _cursor.fetchone()

        # Saves the encrypted strings to a dictionary where key = id and value = encrypteddata
        self._encrypted_data_dict = self._map_device_to_community_string(_connection)

        # Establishes connection to ASM database to retrieve IP and ID
        try:
            _cred_id_connection = psycopg2.connect("dbname = asm_manager user = orion")
            _cred_id_cursor = _cred_id_connection.cursor()
        except psycopg2.OperationalError as e:
            logging.error("failed to make psycopg2 connection to asm_manager. {0}".format(str(e.args[0])).encode("utf-8"))
            raise
        # Saves the IP address to a dictionary where key = cred_id and value = ip_address
        try:
            if service_id is None or service_id == '':
                _cred_id_cursor.execute("SELECT ip_address, cred_id FROM device_inventory")
            else:
                sql_command = "SELECT ip_address, cred_id FROM deployment de INNER JOIN deployment_to_device_map dm ON de.id=dm.deployment_id INNER JOIN device_inventory di ON dm.device_id=di.ref_id WHERE de.id=(%s);"
                data = (service_id,)
                _cred_id_cursor.execute(sql_command, data)
            device_inventory_data = _cred_id_cursor.fetchall()

            # Gets credential information for ESXi
            if service_id is None or service_id == '':
                sql_command = "SELECT os_ip_address, os_admin_password FROM device_inventory WHERE os_image_type LIKE (%s)"
                data = ('%esxi%',)
                _cred_id_cursor.execute(sql_command, data)
            else:
                sql_command = "SELECT os_ip_address, os_admin_password FROM deployment de INNER JOIN deployment_to_device_map dm ON de.id=dm.deployment_id INNER JOIN device_inventory di ON dm.device_id=di.ref_id WHERE de.id=(%s) AND di.os_image_type LIKE (%s);"
                data = (service_id, '%esxi%',)
                _cred_id_cursor.execute(sql_command, data)
            device_inventory_data_esxi = _cred_id_cursor.fetchall()
            self._device_inventory_data = device_inventory_data + device_inventory_data_esxi
            logging.debug("size of device_inventory_data {}".format(len(self._device_inventory_data)))

            # Get credential information for TOR switches from deployed service
            if service_id:
                switch_ip_list = self.__switch_list_for_service(service_id)
                if switch_ip_list:
                    sql_query = "SELECT ip_address, cred_id FROM device_inventory WHERE ip_address IN %s"
                    data = (tuple(switch_ip_list),)
                    _cred_id_cursor.execute(sql_query, data)
                    self._device_inventory_data += _cred_id_cursor.fetchall()

        except psycopg2.OperationalError as e:
            logging.error("PostgreSQL fetch on device_inventory failed. {0}".format(str(e.args[0])).encode("utf-8"))
            raise

        self._device_dict = dict()
        logging.debug("creating device inventory dictionary ")
        for instance in self._device_inventory_data:
            # If the ID exists in the dict already, append it to the list of IP address
            if instance[1] in self._device_dict:
                self._device_dict[instance[1]].append(instance[0])
            # Otherwise, creates a new key/value combination
            else:
                self._device_dict[instance[1]] = [instance[0]]
        logging.debug("size of _device_dict {}".format(len(self._device_dict)))

    def _decrypt(self, encrypted_password):
        """
        inputs the encryptedpassword and returns the decrypted password using AESEncryptionMethod
        """
        decrypted_password = AESEncryptionMethod(self._key)
        return decrypted_password.decrypt(encrypted_password)

    @staticmethod
    def _map_device_to_community_string(_connection):
        """
        Retrieves the device id and the associated snmp v2 community string encrypted data
        ( why they didn't go ahead and unencrypt it I dunno .. but the value in the dictionary are encrypted)
        Returns a dictionary with key = device id and value = encrypted snmp_community string
        """
        try:
            _cursor = _connection.cursor()
            _cursor.execute("SELECT id, encrypteddata FROM encryptedstring")
            encrypted_community_strings = _cursor.fetchall()
            logging.debug("size of encrypted data {}".format(len(encrypted_community_strings)))

            # Saves the Panduit IPI Cabinet appliance encrypted community string to the dictionary
            _cursor.execute("SELECT credential_id, encrypteddata FROM em_credential ec INNER JOIN encryptedstring es ON ec.snmp_community_string_id = es.id")
            encrypted_community_strings = encrypted_community_strings + _cursor.fetchall()

            # Saves SNMP v2 trap idrac encrypted community string to the dictionary
            _cursor.execute("SELECT v2.credential_id, encrypteddata FROM snmp_v2c_credential v2 INNER JOIN encryptedstring es ON v2.snmp_community_string_id = es.id")
            encrypted_community_strings = encrypted_community_strings + _cursor.fetchall()

            # Saves SNMP v2 trap encrypted switch community string to the dictionary
            _cursor.execute("SELECT v2.credential_id, encrypteddata FROM iom_credential v2 INNER JOIN encryptedstring es ON v2.snmp_community_string_id = es.id")
            encrypted_community_strings = encrypted_community_strings + _cursor.fetchall()

            # Saves SNMP v3 trap encrypted security passwords to the dictionary
            _cursor.execute("SELECT es.id, encrypteddata FROM snmp_v3_credential v3 INNER JOIN encryptedstring es ON v3.md5_authentication_password_id = es.id union SELECT es.id, encrypteddata FROM snmp_v3_credential v3 INNER JOIN encryptedstring es ON v3.des_privacy_password_id = es.id")
            encrypted_community_strings = encrypted_community_strings + _cursor.fetchall()

        except psycopg2.OperationalError as e:
            logging.error(" PostgreSQL fetch on encryptedstring failed.  {0}".format(str(e.args[0])).encode("utf-8"))
            raise
        encrypted_community_strings_dict = dict()
        logging.debug("creating encrypted string dictionary")

        for encrypted_instance in encrypted_community_strings:
            encrypted_community_strings_dict[encrypted_instance[0]] = encrypted_instance[1]
        return encrypted_community_strings_dict
	
    def get_credential_information(self, cred_type):
        """
        Retrieves the credential information from the database, stores it in all_credentials which is returned

        input = cred_type = type of machine like 'server' for idrac, 'scaleio' for scaleio etc. cred_type is a value given in the credential table
        """
        try:
            _connection = psycopg2.connect("dbname=encryptionmgr user=orion")
            _cursor = _connection.cursor()
            # getting username, passwordid and id from credential table by passing in cred_type provided in the specific get_*_credentials functions, cred_type is used to identify type of device
            sql_command = " SELECT username, passwordid, id FROM credential WHERE credtype LIKE (%s);"
            data = (cred_type,)
            _cursor.execute(sql_command, data)
            credentials = _cursor.fetchall()
            all_credentials = []
            for credential in credentials:
                # Checks _encrypted_data_dict for key
                if credential[1] in self._encrypted_data_dict:
                    # Checks _device_dict for key
                    if credential[2] in self._device_dict:
                        ip_addr = self._device_dict[credential[2]]
                        username = credential[0]
                        decrypted_password = self._decrypt(self._encrypted_data_dict[credential[1]])
                        for i in ip_addr:
                            all_credentials.append(Credential(username, decrypted_password, i, credential[2], self))

            logging.debug("size of credentials is {}".format(len(all_credentials)))
            return all_credentials

        except psycopg2.DatabaseError as e:
            logging.error("error accessing credential table.  {0}".format(str(e.args[0])).encode("utf-8"))
			
			
    def get_idrac_credentials(self):
        """
        Returns the idrac credential information by passing in 'server' string to the get_credential_information function
        """
        idrac_credentials = self.get_credential_information("server")
        return idrac_credentials

    def get_snmp_v2_trap_credential(self, v2_user_id):
        """
        v2_user_id - a single credential_id as used in credential table id column
        returns - community_string or None if not found
        """
        if v2_user_id in self._encrypted_data_dict:
            return self._decrypt(self._encrypted_data_dict[v2_user_id])
        return None

    def get_credential_ids_from_device_inventory(self):
        """
        This funtion fetch the cred_id(s) from the device inventory table for SNMPv3 (used for mapping between user and device )
        return : list of cred_id(s) present in the device inventory
        """

        try:
            _connection = psycopg2.connect("dbname=asm_manager user=orion")
            _cursor = _connection.cursor()
            _cursor.execute("SELECT cred_id from device_inventory")
            cred_id_records = _cursor.fetchall()
            return [cred_tuple[0] for cred_tuple in cred_id_records] # converting tuples to return as list of cred_ids

        except psycopg2.OperationalError as e:
            logging.error("failed to make psycopg2 connection to asm_manager. {0}".format(str(e.args[0])).encode("utf-8"))
            raise

    def get_snmp_v3_user_credentials_for_listening(self, credential_id):
        """
        this function accepts credential id (in credential_id)
        return : snmpv3_username, snmpv3_security_level, snmpv3_md5_passphrase, snmpv3_des_passphrase
        """

        try:
            device_inventory_cred_id_list = self.get_credential_ids_from_device_inventory()
            _connection = psycopg2.connect("dbname=encryptionmgr user=orion")
            _cursor = _connection.cursor()
            _cursor.execute("SELECT id, v3.username, security_level, md5_authentication_password_id, des_privacy_password_id FROM snmp_v3_credential v3 INNER JOIN credential c ON c.id = v3.credential_id")
            v3_user_db_records = _cursor.fetchall()
            v3_user_record_dict = {}
            v3_keys = ('id', 'username', 'securityLevel', 'md5Password', 'desPrivacyPassword')
            for v3_user_db_record in v3_user_db_records:
                v3_user_record_dict[v3_user_db_record[0]] = dict(zip(v3_keys, v3_user_db_record))

            if credential_id in v3_user_record_dict and credential_id in device_inventory_cred_id_list :
                v3_listening_dict = self._decrypt_v3_security_credentials(v3_user_record_dict[credential_id])
                return v3_listening_dict["username"], v3_listening_dict["securityLevel"], v3_listening_dict["md5Password"], v3_listening_dict["desPrivacyPassword"]
            return None, None, None, None

        except psycopg2.OperationalError as e:
            logging.error("failed to make psycopg2 connection to encryptionmgr. {0}".format(str(e.args[0])).encode("utf-8"))
            raise


