"""
*   Copyright (c) 2018 Dell Inc. All rights reserved.                    *
*                                                                        *
* DELL INC. CONFIDENTIAL AND PROPRIETARY INFORMATION. This software may  *
* only be supplied under the terms of a license agreement or             *
* nondisclosure agreement with Dell Inc. and may not be copied or        *
* disclosed except in accordance with the terms of such agreement.       *
"""

import json
import logging
import requests
from requests import exceptions as request_exceptions
from requests.packages.urllib3.exceptions import InsecureRequestWarning

import urllib3
urllib3.disable_warnings(InsecureRequestWarning) #Disables verification warning

PUPPET_URL = 'http://{0}:{1}/'.format(os.getenv("PUPPET_HOST"), os.getenv("PUPPET_PORT"))

def get_nodes():
    """
    Uses the puppet api to retrieve the nodes known in inventory.
    """
    try:
        header = {
            'Content-Type': "application/json",
            'Accept': "application/json",
            'Cache-Control': "no-cache"
            }
        res = requests.request("GET", PUPPET_URL+'pdb/query/v4/nodes', headers=header)
        res.raise_for_status()
        results = json.loads(res.text)
        return results
    except request_exceptions.HTTPError as errh:
        logging.error('HTTP error from Puppet: %s', str(errh))
    except request_exceptions.ConnectionError as errc:
        logging.error("Connection Error from Puppet: %s", (str(errc)))
    except request_exceptions.Timeout as errt:
        logging.error("Connection timeout to Puppet: %s", (str(errt)))
    return None
