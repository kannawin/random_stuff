"""
*   Copyright (c) 2018 Dell Inc. All rights reserved.                    *
*                                                                        *
* DELL INC. CONFIDENTIAL AND PROPRIETARY INFORMATION. This software may  *
* only be supplied under the terms of a license agreement or             *
* nondisclosure agreement with Dell Inc. and may not be copied or        *
* disclosed except in accordance with the terms of such agreement.       *
"""

from datetime import datetime
import json
import logging
import requests
from requests import exceptions as request_exceptions
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import os

import urllib3
urllib3.disable_warnings(InsecureRequestWarning) #Disables verification warning

from dell.puppet.nodes import get_nodes


PUPPET_URL = 'http://{0}:{1}/'.format(os.getenv("PUPPET_HOST"), os.getenv("PUPPET_PORT"))

def get_facts_by_ip(ip_address):
    """
    Uses the puppet api to retrieve the nodes.
    iterates through the known nodes to find the certname associated with the ip_address
    returns get_facts using the discovered certname / None if not found
    """
    all_nodes = get_nodes()
    for node in all_nodes:
        if "certname" in node and ip_address in node["certname"]:
            return get_facts(node["certname"])
    return None


def get_facts(cert_name):
    """
    Uses the puppet api to retrieve the facts for a known device.
    The cert_name is normally of the form asm-{IP} where the {IP} is the address of the device
    """
    try:
        header = {
            'Content-Type': "application/json",
            'Accept': "application/json",
            'Cache-Control': "no-cache"
            }
        query_string = r'query=["=", "certname", "{CERT}"]'.format(CERT=cert_name)
        res = requests.request("GET", PUPPET_URL+'pdb/query/v4/inventory', headers=header, params=query_string)
        res.raise_for_status()
        results = json.loads(res.text)
        if results:
            first_item = results[0]
            # Gavin noted:
            # old puppet didn't support complex structures, so data was stored in "json_facts"
            # the existing ruby unpacks and re-packs this fact
            # thus same code here
            # https://github.com/dell-asm/asm-deployer/blob/master/lib/asm/client/puppetdb.rb#L72
            if "json_facts" in first_item["facts"]:
                logging.debug("converting json_facts to hash")
                json_facts = json.loads(first_item["facts"]["json_facts"])
                for key in json_facts:
                    first_item["facts"][key] = json_facts[key]
                del first_item["facts"]["json_facts"]
            return first_item
    except request_exceptions.HTTPError as errh:
        logging.error('HTTP error from Puppet: %s', str(errh))
    except request_exceptions.ConnectionError as errc:
        logging.error("Connection Error from Puppet: %s", (str(errc)))
    except request_exceptions.Timeout as errt:
        logging.error("Connection timeout to Puppet: %s", (str(errt)))
    return None

def merge_facts(cert_name, new_facts):
    """
    Uses the puppet api to merge the specified json into the inventory
        of a device specified by cert_name.
    The cert_name is normally of the form asm-{IP} where the {IP} is the address of the device
    Returns: the result of the puppet job.
        Usually a jobid of the format {u'uuid': u'118b3d3c-65eb-412f-a60f-9ceb9822ffc8'}
    """
    try:
        facts = get_facts(cert_name)
        logging.debug("Retrieved {} facts for {}".format(len(facts), cert_name))
        for key in new_facts:
            facts["facts"][key] = new_facts[key]
        header = {
            'Content-Type': "application/json",
            'Accept': "application/json",
            'Cache-Control': "no-cache"
            }
        facts["facts"]["update_time"] = datetime.utcnow().strftime("%4Y-%2m-%2dT%H:%M:%S+00:00")
        payload = {
            "certname" : cert_name,
            "environment" : "PROD",
            "producer_timestamp" : facts["facts"]["update_time"],
            "producer" : None,
            "values" : facts["facts"]
            }
        url = PUPPET_URL + "pdb/cmd/v1?command=replace_facts&version=5&secondsToWaitForCompletion=60&certname={CERT}".format(CERT=cert_name)
        res = requests.request("POST", url, headers=header, json=payload)
        res.raise_for_status()
        logging.debug("Return from post is {}".format(res.text))
        results = json.loads(res.text)
        return results
    except request_exceptions.HTTPError as errh:
        logging.error('HTTP error from Puppet: %s', str(errh))
    except request_exceptions.ConnectionError as errc:
        logging.error("Connection Error from Puppet: %s", (str(errc)))
    except request_exceptions.Timeout as errt:
        logging.error("Connection timeout to Puppet: %s", (str(errt)))
    return None
