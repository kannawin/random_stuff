#!/usr/bin/python3

import uuid
import copy
import logging
import psycopg2
import psycopg2.extras

from psycopg2 import sql

#current postgres username
pg_username = 'orion'

EVENT_FORMAT = {
    "uid" : None,
    "code": None,
    "description": None,
    "severity": None,
    "timestamp": None,
    "resource_name": None,
    "resource_type": None,
    "resource_id": None,
    "service": None,
    "details": {},
    "category": None,
    "originator_application": None,
    "snmp": None,
    "request_id": None,
    "related_events": None,
    "job_id": None
}


def fetch_one_with_where(dbname, select_statement, from_statement, reference, reference_value):
    """
        This function connect to pg database and fetch one row of data that hits

    Args:
        dbname: str, name of the db in PG
        select_statement: list<str>, values to select from in statement
        from_statement: str, from statement specify the name of the table.
        referenece: str, key value to compare in WHERE statement
        referenece_value: str, value used in the reference to seelct
    Returns:
        device_record: {}, the data that is retrieved from the PG DB
    """

    connection = None

    if not isinstance(dbname, str):
        raise TypeError("dbname has to be string")

    if not isinstance(from_statement, str):
        raise TypeError("from statement has to be string")

    try:
        connection = psycopg2.connect("dbname={} user={}".format(dbname, pg_username), cursor_factory=psycopg2.extras.RealDictCursor)
        cursor = connection.cursor()

        query = sql.SQL("SELECT {fields} FROM {table} WHERE {ref}=%s").format(
            fields=sql.SQL(',').join(
                sql.Identifier(n) for n in select_statement),
            table = sql.Identifier(from_statement),
            ref = sql.Identifier(reference))

        logging.info(query)
        cursor.execute(query, (reference_value,))
        device_record = cursor.fetchone()
    except Exception as db_error:
        error_msg = "Failed to fetch records from the database {}".format(db_error)
        logging.error(error_msg)
        raise
    finally:
        if connection is not None:
            cursor.close()
            connection.close()
            logging.info('Connection to asm_manager DB is closed.')

    return device_record


def get_device_info(trap):
    device = fetch_one_with_where("asm_manager",["ref_id"],"device_inventory", "ip_address", trap['SourceIpAddress'])
    return device['ref_id']


def device_deployment(dev_ref_id):
    device = fetch_one_with_where("asm_manager", ["device_id", "deployment_id"], "deployment_to_device_map", "device_id", dev_ref_id)
    return device['deployment_id'] if device is not None else ""


"""
Used with the current snmp trap conversion service in /usr/lib/python2.7/site-packages/dell/snmp_trap_converison.py
in cbFun the msg_body variable will be fed into this method to convert into event format

returns the msg_body parsed into event format

"""

def translate_event(msg_body):
    event = copy.deepcopy(EVENT_FORMAT)
    trap = msg_body['trap']
    if trap is not None:

        #IDRAC event
        if trap['IDRAC-MIB-SMIv2::alertMessage.0'] is not None:
            event['details']['symptomCode'] = trap['IDRAC-MIB-SMIv2::alertMessageID.0']
            event['resource_name'] = trap['IDRAC-MIB-SMIv2::alertChassisServiceTag.0']
            event['description'] = trap['IDRAC-MIB-SMIv2::alertMessage.0']
        #cloudlink
        elif 'DELLEMC-CL-SURVEILLANCE-MIB::clAlarmId' in trap and trap['DELLEMC-CL-SURVEILLANCE-MIB::clAlarmId'] is not None:
            event['details']['symptomCode'] = trap['DELLEMC-CL-SURVEILLANCE-MIB::clAlarmId']
            if 'DELLEMC-CL-SURVEILLANCE-MIB::clAlarmDetails' in trap:
                event['description'] = trap['DELLEMC-CL-SURVEILLANCE-MIB::clAlarmDetails']
                event['resource_name'] = trap['DELLEMC-CL-SURVEILLANCE-MIB::clAlarmTargetName']
            else:
                event['description'] = trap['SNMPv2-MIB::snmpTrapOID.0']
        #OS 9/10 event
        elif 'DELLEMC-OS10-SMI-MIV::enterpriseSW' in trap and trap['DELLEMC-OS10-SMI-MIB::enterpriseSW'] is not None:
            event['details']['symptomCode'] = trap['SNMPv2-MIB::snmpTrapOID.0']
            event['description'] = trap['DELLEMC-OS10-SMI-MIB::enterpriseSW']
            event['resource_name'] = trap['SourceIpAddress']


        ref_id = get_device_info(trap)
        service = device_deployment(ref_id)

        event['uid'] = str(uuid.uuid1())
        event['severity'] = trap['SeverityName']
        event['timetsamp'] = trap['TimeStamp']
        event['resource_type'] = msg_body['device_type']
        event['resource_id'] = ref_id
        event['service_id'] = device_deployment(ref_id)
        if 'DetailedDescription' in trap:
            event['details']['detailedDescription'] = trap['DetailedDescription']
        if 'CategoryName' in trap:
            event['category'] = trap['CategoryName']
        event['originator_application'] = None

        event['originator_application'] = None
        event['snmp'] = trap
        event['request_id'] = None
        event['related_events'] = None
        event['job_id'] = None

    return event
 
